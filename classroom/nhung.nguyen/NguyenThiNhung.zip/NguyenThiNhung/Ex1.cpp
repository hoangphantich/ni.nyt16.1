#include<iostream>
using namespace std;
main(){
	int n, fb, fb1, fb2;
	
    cout<<"Input 1 number (>1) ";
    cin>>n;
	fb1=1; fb2=1;
	int sum;
	sum=fb1+fb2;
	cout<<"1 1 ";
    while(fb1+fb2<n)
    {
    	fb=fb1+fb2;
        fb2=fb1;
        fb1=fb;
        sum+=fb;
        cout<<fb<<" ";
    }
    cout<<endl;
    cout<<"Sum : "<<sum;
    
}
