#include<iostream>
using namespace std;
main(){
	int c=25000;
	int minutes;
	cout<<"Input minutes of using : ";
	cin>>minutes;
	if(minutes<=50){
		cout<<c<<"+"<<minutes<<"*"<<600<<"="<<c+minutes*600;
	}
	else if(minutes<=200){
		cout<<c<<"+"<<50<<"*"<<600<<"+"<<(minutes-50)<<"*"<<400<<"="<<c+50*600+(minutes-50)*400;
	}
	else{
		cout<<c<<"+"<<50<<"*"<<600<<"+"<<150<<"*"<<400<<"+"<<minutes-200<<"*"<<200<<"="<<c+50*600+150*400+(minutes-200)*200;
	}
	cout<<endl;
	
}
