/*
Owner: Ngo Duc Dung
Added: 21/06/2016
Last update: 21/06/2016
*/

#ifndef MANAGE_FILE_H
#define MANAGE_FILE_H

#include "structs.h"

void saveToFile(Class* classes, int class_id);
void getFromFile(Class* classes);

#endif
