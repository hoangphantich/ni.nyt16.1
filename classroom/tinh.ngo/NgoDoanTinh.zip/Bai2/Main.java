package Bai2;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Telephone Cost: "+TelephoneCost.cost2(300));
		System.out.println("Telephone Cost: "+TelephoneCost.cost1(300));
	}

}
