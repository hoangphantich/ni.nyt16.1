package Bai3;

public class Student {
	
	public int id;
	public String name;
	public String birthday;
	public int winmark;
	public int wordmark;
	public int jiramark;
	public int sum;
	public String rank;
	
}
