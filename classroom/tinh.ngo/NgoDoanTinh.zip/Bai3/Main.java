package Bai3;

public class Main {

	public static void main(String[] args) {
		
		StudentManager manager = new StudentManager();
		manager.inputStudent();
		manager.printStudent1();
		manager.inputMark();
		manager.sumStudent();
		manager.printStudent2();
	}

}
