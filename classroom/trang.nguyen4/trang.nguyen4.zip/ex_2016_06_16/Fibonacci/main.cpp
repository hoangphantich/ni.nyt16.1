/**
 * Nguyen Minh Trang
 * 2016/06/21
 * Project: Fibonacci
 */


#include "Fibonacci.h"


int main() {
	Fibonacci fibonacci;

	fibonacci.getMaxNumber();
	fibonacci.findFibonacciNumbers();
	fibonacci.printResults();
	
	return 0;
}

