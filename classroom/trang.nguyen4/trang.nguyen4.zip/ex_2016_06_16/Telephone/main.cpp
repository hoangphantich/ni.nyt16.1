/**
 * Nguyen Minh Trang
 * 2016/06/21
 * Project: Telephone Cost
 */


#include "Telephone.h"


int main() {
	Telephone telephone;
	telephone.getMinutes();
	telephone.findTelephoneCost();
	telephone.printResult();
	
	return 0;;
}
