/**
 * Nguyen Minh Trang
 * 2016/06/21
 * Project: Student Manager
 */

#include<vector>

#include "StudentManager.h"


int main() {
	StudentManager manager;
	
	while (true) {
		manager.showMenu();
	}

	return 0;
}

