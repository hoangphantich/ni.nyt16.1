/**
 * Nguyen Minh Trang
 * 2016/06/19
 * Project: Student Manager
 */


#include "StudentManager.h"


int main() {
	StudentManager manager;

	while (true) {
		manager.showMenu();
	}

	return 0;
}

