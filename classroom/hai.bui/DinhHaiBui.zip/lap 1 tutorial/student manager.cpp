#include <iostream>
#include <conio.h>    
#include <iomanip>  
#include <stdio.h>
#include <String.h>
using namespace std; 
 
struct student{
	int id;
	string name;
	string birth;
	int winMark;
	int wordMark;
	int jiraMark;
	int sum;
	string rank;
}; 

struct Node
{ 	
	student s;
	Node *next;
};
 
Node *head, *tail;
int number = 0;


//set student information detail 
student info(student s){
	
	s.id = ++number;
	fflush(stdin);
	
	cout << "input name: ";
	getline(cin, s.name);
	fflush(stdin);
	
	cout << "input date of birth: ";
	getline(cin, s.birth);
	fflush(stdin);
	
	cout << "win mark: ";
	cin >> s.winMark;
	cout << "word mark: ";
	cin >> s.wordMark;
	cout << "jira mark: ";
	cin >> s.jiraMark;
	fflush (stdin);
	
	s.sum = s.winMark + s.wordMark + s.jiraMark;
	if(s.sum < 0){
		s.rank = "";
	}
	else if(s.sum < 18){
		s.rank = "Average";
	}
	else if(s.sum < 24){
		s.rank = "Good";
	}
	else{
		s.rank = "Excellence";
	}
	return s;
}
 
// add 1 student to end of list
void addStudent(student s){
   Node *p;   
   p->s = s;                     
   p->next = NULL;  
   if (head == NULL)                       
      head = p;
   else
       tail->next = p;
   tail = p;                              
}
 

 // show list to console
void showlist(){
    Node *p = head;
    cout << setw(3) << "STT" << setw(10) << "Name" << setw(30) << "Birthday" << setw(10) << "Sum" << setw(10) << "Rank" << endl;
    while (p != NULL)
    {
       cout  << setw(3) << p->s.id << setw(10) << p->s.name << setw(30) << p->s.birth << setw(10) << p->s.sum << setw(10) << p->s.rank  << endl;    
		 p = p->next;
    }
    
}

 
 
 //interface menu
void menu(){
	cout << endl << endl;
	cout << "Menu" << endl;
	cout << "1: Input new Student info" << endl;
	cout << "2: Output Student" << endl;
	cout << "------------------------------" << endl;
	cout << "Choose your number: ";
}



int main(){
	cout << "Student Manager" << endl;
	
	head = NULL;
	tail = NULL;
	
	int choose;
	student s;
	
	do{
		menu();
		cin >> choose;
		switch(choose){
			case 1:{
				s = info(s);
				addStudent(s);	
				break;
			}
			
			case 2:{
				showlist();
				break;
			}
		}		
	}while(1);
	
	return 0;
}



