#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
 
typedef struct tagSINHVIEN {
      Name String(30);
     Birthday		String(8);
     Win-mark		int;
     Word-mark		int;
     Jira-mark		int;
     Sum			int;
     Rank			String(20);

   
}SINHVIEN, *PSINHVIEN;
 
typedef struct tagNODE {
    SINHVIEN Data;
    tagNODE* Next;
}NODE, *PNODE;
 
typedef struct tagLIST {
    NODE* Dau;
    NODE* Cuoi;
}LISTSV, *PLIST;
 
//Khoi tao NODE
NODE* KhoitaoNode()
{
    NODE* x = (NODE*)malloc(sizeof(NODE));
    if(x == NULL)
    {
        printf("\n Bo nho khong du ");
        return 0;
    }
    x->Next = NULL;
    return x;
}
 
//Khoi tao danh sach LISTSV
void KhoitaoList(LISTSV* x)
{
    x->Dau = NULL;
    x->Cuoi=NULL;
}
 
//Nhap thong tin sinh vien
void Nhap (NODE* x)
{
    char tg[25];
    int a, d, m, y;
    float t, c;
     printf("Nhap ten Sinh Vien: ");
    gets(tg);
    strcpy(x->Data.Hoten,tg);d
    fflush(stdin);
    
   
    do
    {
        printf("Nhap Ngay Sinh: ");
        scanf("%d", &d);
        fflush(stdin);
    }while(d > 31 || d < 1);
    x->Data.ngay = d;
    do
    {
        printf("Nhap Thang Sinh: ");
        scanf("%d", &m);
        fflush(stdin);
    }while(m > 12 || m < 1);
    x->Data.thang = m;
    do
    {
        printf("Nhap Nam Sinh: ");
        scanf("%d", &y);
        fflush(stdin);
    }while(y > 9999 || y < 1000);
    x->Data.nam = y;
    fflush(stdin);
    do
    {
        printf("Nhap Diem Win-mark	: ");
        scanf("%f", &c);
    }while(c < 0 || c > 10);
    x->Data.Toan = c;
    fflush(stdin);
    do
    {
        printf("Nhap Diem Word-mark	: ");
        scanf("%f", &t);
    }while(c < 0 || c > 10);
    x->Data.Van = t;
      do
    {
        printf("Nhap Diem Jira-mark	: ");
        scanf("%f", &t);
    }while(c < 0 || c > 10);
    x->Data.jira = t;
    
    x->Data.TK = (x->Data.Toan + x->Data.Van+x->Data.jira);
    fflush(stdin);
    x->Next = NULL;
    
}
//in sinh vien
void InSV(NODE* p)
{
   
    printf("\tTen Sinh vien: %s  ",p->Data.Hoten);
    printf("\nNgay/ Thang/ Nam sinh: %5d/%5d/%5d   ", p->Data.ngay, p->Data.thang, p->Data.nam);
    printf("\nDiem Win-mark: %.2f   ", p->Data.Toan);
    printf("\tDiem Word-mark: %.2f   ", p->Data.Van);
    printf("\tDiem Jira-mark: %.2f   ", p->Data.jira);
    
    printf("\tDiem tong ket: %.2f\n\n\n", p->Data.TK);
}
 
void inSVGioi(LISTSV x)
{
    NODE *p;
    p = x.Dau;
    while(p != NULL)
    {
        if(p->Data.TK >= 24)
        {
            InSV(p);
        }
        p = p->Next;
    }
}
 
//In cac Sinh Vien xep Loai Kha
void inSVKha(LISTSV x)
{
    NODE *p;
    p = x.Dau;
    while(p != NULL)
    {
        if(p->Data.TK < 24 && p->Data.TK >= 18)
        {
            InSV(p);
        }else printf("\n Khong co sinh vien dat tieu chuan can tim\n");
        p = p->Next;
    }
}
 
//Liet ke so SINHVIEN bi thi Lai
 
void inSVThilai(LISTSV x)
{
    NODE *p;
    p = x.Dau;
    while(p != NULL)
    {
        if(p->Data.Toan < 5 || p->Data.Van < 5)
        {
            InSV(p);
        } else printf("\n Khong co sinh vien dat tieu chuan can tim\n");
        p = p->Next;
    }
}
 
