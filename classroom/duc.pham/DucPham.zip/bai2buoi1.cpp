#include <iostream>
#include <iomanip>

using namespace std;

int main()
{  
  int starttime;
  int minutes;
  const float tax = 0.04;
  const float flatrate = 0.35;
  const float mindiscount = 0.15;
  const float timediscount = 0.5;
  float callrate = float (minutes * flatrate); // the standard call rate stored in a variable.
  float gross;    // the gross cost before discount
  float net;      // the net cost

    cout << "enter start time: " << endl;
    cin >> starttime;
    if (starttime > 2499) // a check put inplace so someone doesn't enter an invalid time integer
        {cout << "You entered an invalid time. Should only be based on the 24 hour clock " << endl;
        return 1;}
    cout << "enter total minutes: " << endl;
    cin >> minutes;
    gross = callrate;
    cout << "gross cost: " << gross << setprecision(2) << endl;
    {if ((minutes < 60 ) && (starttime < 1800 && starttime > 800)) // if no discounts are made, this is the final price before tax
         net = gross;
    else if (starttime > 1800 || starttime < 800) // if the call is between 6:00 PM and 8:00 AM, it gets a 50% discount
        net = gross - (gross * timediscount);}
    if (minutes > 60 )          // if the call lasted longer than 60 minutes, it gets a 15% discount
        net = net - (net * mindiscount);
    cout << "net cost: " << float (net + (net * tax)) << setprecision(2) << endl; // the final net cost with the 4% tax added.
    return 0;}
