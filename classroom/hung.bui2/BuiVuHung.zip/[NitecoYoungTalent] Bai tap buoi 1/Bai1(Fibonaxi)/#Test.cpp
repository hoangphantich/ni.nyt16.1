#include <iostream>
#include <fstream>

using namespace std;

//Ham Fibonaxi
int F(int n)
{
    if(n==1)
        return 1;
    if(n==2)
        return 1;
    else
        return F(n-1)+F(n-2);
}

int main()
{
    //max, nhap max
    int n;
    cout << "Nhap 1 so : ";
    cin >> n;

    int i = 1;

    //lien tuc in ra day fibonaxi
    while (true)
    {
        if(F(i)<=n)
        {
            cout<< F(i) << "  ";
            i++;
        }
        //Neu vuot qua Max thi thoat khoi vong lap
        else
            break;
    }

    return 0;
}
