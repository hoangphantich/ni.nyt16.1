#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int Mins;
    cout<<"Nhap so phut goi :";
    cin >> Mins;
    int muc1 = 600*50;
    int muc2 = 400*150;
    int cuoc1 = 25000;
    int cuocPhi;


    if (Mins <= 0)
    {
         cout<< "Something Wrong !";
         goto nhay;
    }
    else if(50< Mins && Mins <= 200)
        cuocPhi = cuoc1 + muc1 + 400*(Mins - 50);
    else if (Mins > 200)
        cuocPhi = cuoc1 + muc1 + muc2 + 200*(Mins - 200);
    else
        cuocPhi = cuoc1 + Mins*600;
    cout<< "Cuoc phi cuoc goi vua roi la : "<<cuocPhi;

nhay: return 0;
}
