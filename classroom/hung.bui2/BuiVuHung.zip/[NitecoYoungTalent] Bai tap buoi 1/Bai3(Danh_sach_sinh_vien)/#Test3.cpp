#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

typedef struct Student
{
    char Name[30];
    char Birthday[8];
    int Winmark;
    int Wordmark;
    int Jiramark;
    int sum;
    string Rank;
} Student;

int main()
{
    int n;
    cout<< "Nhap so sinh vien : ";
    cin >> n;

    Student* lists = new Student[n];
    for(int i=0;i<n;i++)
    {
        cout<< "Nhap ten hoc sinh thu "<<i + 1<< " : ";
        cin >> lists[i].Name;
        cout<< "Ngay sinh hoc sinh thu "<< i+1 <<" : ";
        cin >> lists[i].Birthday;
        cout<< "diem Win cua hoc sinh thu "<< i+1 <<" : ";
        cin >> lists[i].Winmark;
        cout<< "diem Word cua hoc sinh thu "<< i+1 <<" : ";
        cin >> lists[i].Wordmark;
        cout<< "diem Jira cua hoc sinh thu "<< i+1 <<" : ";
        cin >> lists[i].Jiramark;

        lists[i].sum = lists[i].Winmark + lists[i].Wordmark + lists[i].Jiramark;
        if(lists[i].sum < 18)
            lists[i].Rank = "Average";
        else if(lists[i].sum >= 24)
            lists[i].Rank = "Exellence";
        else
             lists[i].Rank = "Good"   ;
    }


    cout<<endl<<endl << "STT    Name    Birthday    Sum     Rank";
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        cout<< i+1 <<"      "<< lists[i].Name <<"       "<<lists[i].Birthday <<"        "<<lists[i].sum <<"      "<<lists[i].Rank;
        cout<< endl;
    }

    return 0;
}
