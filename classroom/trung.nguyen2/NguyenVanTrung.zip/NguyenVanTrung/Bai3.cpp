#include <iostream>
#include <stdio.h>
#include <conio.h>
using namespace std;

typedef struct sinhvien{
	char name[30];
	char birthday[8];
	int winMark;
	int wordMark;
	int jiraMark;
	int sum;
	char rank[20];  
}SV;
typedef struct node{
	sinhvien* data;
	struct node *next;
}NODE;
node *head;
node *create(sinhvien *sv){
	node *p = new node;
	if(p == NULL) return 0;
	p->data=sv;
	p->next=NULL;
	return p;
}
sinhvien *createSV(){
	sinhvien *sv = new sinhvien;
	fflush(stdin);
	cout<<"\nNhap ten sinh vien: "; gets(sv->name);
	cout<<"\nNhap ngay sinh: "; gets(sv->birthday);
	cout<<"\nNhap diem Win-mark: ";cin>>sv->winMark; 
	cout<<"\nNhap diem Work-mark: ";cin>>sv->wordMark;
	cout<<"\nNhap diem Jira-mark: ";cin>>sv->jiraMark;
	return sv;
}
void insertFirst(node *&head, sinhvien *sv){
	node *p = create(sv);
	if(head == NULL) head = p;
	else{
		p->next = head;
		head = p;
	}
}
void insertEnd(node *&head, sinhvien *sv){
	node *p = create(sv);
	if(head == NULL) head = p;
	else{
		node *temp = head;
		while(temp ->next!=NULL){
			temp = temp->next;
			temp->next = p;
		}
	}
}
string rank(int sum){
	if(sum>=24){
		return "Exellence";
	} else if(sum<24 && sum>=18){
		return "Good";
	}else if(sum <18){
		return "Average";
	}	
}
void display(node *head){
	if(head == NULL){
		cout<<"Danh sach rong!.\n";
	}
	else{
		cout<<"Danh sach sinh vien:\n";
			printf("STT");
			printf("%10s","Name");
			printf("%10s","Birthday");
			printf("%10s","Win-Mark");
			printf("%10s","Word-Mark");
			printf("%10s","Jira-Word");
			printf("%10s","Sum");
			printf("%10s","Rank");
			int i = 1;
		for(node *p=head; p!=NULL; p = p->next){
			int sum = p->data->winMark + p->data->wordMark+ p->data->jiraMark;
			cout<<"\n"<<i<<"\t";
			cout<<"\n"<<p->data->name<<"\t";
			cout<<p->data->birthday<<"\t";
			cout<<p->data->winMark<<"\t  ";
			cout<<p->data->wordMark<<"\t\t";
			cout<<p->data->jiraMark<<"\t   ";
			cout<<sum<<"\t";
			cout<<rank(sum)<<"\t";
			cout<<"\n---------------------------\n";
			i++;
		}
	}
}

int main(){
	int chon,tt = 1;
	sinhvien *sv;
	do{ 
	cout<<"\n";
	cout<<"\nHay chon chuc nang\n";
	cout<<"0. Thoat\n";
	cout<<"1. Them sinh vien dau danh sach\n";
	cout<<"2. Them sinh vien cuoi danh sach\n";
	cout<<"3. Hien thi danh sach\n";
	cout<<"\n---------------------------\n";
	cin>>chon;
	switch(chon){
		case 1:
			{
				cout<<"Nhap thong tin cho 1 sinh vien:\n";
				sv = createSV();
				insertFirst(head,sv);
				cout<<"Danh sach sau khi them:\n";
				display(head);
				break;
			}
		case 2:
			{
			cout<<"Nhap thong tin cho 1 sinh vien:\n";
				sv = createSV();
				insertEnd(head,sv);
				cout<<"Danh sach sau khi them:\n";
				display(head);
				break;	
			}
		case 3:
			display(head);
			break;
		case 0:
			tt= 0;
			break;
	}
	}while(tt == 1);
	getch();
	return 0;
}
