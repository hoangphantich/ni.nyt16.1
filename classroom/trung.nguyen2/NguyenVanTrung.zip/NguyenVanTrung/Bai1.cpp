#include <iostream>
#include <stdio.h>
using namespace std;
int fibonaci(int x){
	if(x == 0 || x == 1){
		return 1;
	}
	else{
		return (fibonaci(x - 2) + fibonaci(x - 1));
	}
}
int test(){
	int n;
	int sum = 0;
	cout << "\nNhap vao so nguyen n =";
	cin >> n;
	if(n<=0){
		cout<< "N phai la so nguyen duong";
		test();
	}
	else{
		int i = 0;
		while(fibonaci(i)<n){
	
		int k = fibonaci(i);
		sum+=k;
		cout<<" "<<k<<" ";
		i++;
	}
	cout<<"\nSum="<<sum;
	}	
}
int main(){
	test();
	return 0;
}
