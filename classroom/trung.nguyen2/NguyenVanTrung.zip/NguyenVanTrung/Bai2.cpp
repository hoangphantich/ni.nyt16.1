#include <iostream>
#include <stdio.h>
using namespace std;

int Caculator(int minutes){
	const double cost = 25000;
	double price = 0;
	if(minutes <=50){
		price = cost + minutes*600;
		cout<<cost<<"+"<<minutes<<"*"<<600;
	}else if(minutes>50 && minutes <=150){
		int muc1 = 50;
		int du = minutes - muc1;
		price = cost+ muc1*600 + du*400;
		cout<<cost<<"+"<<muc1<<"*"<<600<<du<<"*"<<400; 
	}else if (minutes>150){
		int muc1 = 50;
		int muc2 = 150;
		int du = minutes - 50 - 150;
		price  = cost + muc1*600 + muc2*400 + du*200;
		cout<<cost<<"+"<<muc1<<"*"<<600<<"+"<<muc2<<"*"<<400<<"+"<<du<<"*"<<200; 
	}
	return price;
}
int main(){
	cout<<"\n"<<Caculator(500);
}
